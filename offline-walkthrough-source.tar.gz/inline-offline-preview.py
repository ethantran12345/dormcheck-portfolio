from base64 import b64encode
from pathlib import Path
import re
import sys

public = Path("public")
dist = Path("offline-dist")
html = (dist / "offline-preview.html").read_text()

def data_url(path, content_type):
    asset = public / path.lstrip("/")
    return f"data:{content_type};base64,{b64encode(asset.read_bytes()).decode()}"

def inline_script(match):
    js = (dist / match[1]).read_text()
    js = re.sub(r"/landing/[\w-]+\.jpg", lambda m: data_url(m[0], "image/jpeg"), js)
    return f"<script type=\"module\">{js.replace('</script', '<' + chr(92) + '/script')}</script>"

def inline_style(match):
    css = (dist / match[1]).read_text()
    css = re.sub(r"/fonts/[\w.-]+\.woff2", lambda m: data_url(m[0], "font/woff2"), css)
    return f"<style>{css}</style>"

html = re.sub(r'<script[^>]+src="\./([^"]+)"[^>]*></script>', inline_script, html)
html = re.sub(r'<link[^>]+href="\./([^"]+\.css)"[^>]*>', inline_style, html)
Path(sys.argv[1]).write_text(html)
