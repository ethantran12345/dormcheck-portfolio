Overlay this archive onto the extracted DormCheck web source snapshot, then run:

    npm ci
    npx vite build --config vite.offline.config.ts
    python3 inline-offline-preview.py dormcheck-offline-demo.html

Open the resulting file directly in a browser. The original marketing walkthrough components render with sample content.
