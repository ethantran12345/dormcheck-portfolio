import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

export default defineConfig({
  base: "./",
  publicDir: false,
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "src") } },
  build: {
    outDir: "offline-dist",
    assetsInlineLimit: 1000000,
    rollupOptions: { input: path.resolve(import.meta.dirname, "offline-preview.html") },
  },
});
