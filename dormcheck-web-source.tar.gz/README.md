# DormCheck web source

This snapshot contains the original React and TypeScript web client, including the UI and routing for roommate matching, move-in checklists, housing exploration, the student marketplace, subleases, and messaging. It includes the source tests and Supabase client types.

## Build locally

Use Node.js 22.12 or later.

```sh
npm ci
cp .env.example .env.local
npm run build
npm run preview
```

The example configuration points at localhost. It supports building and previewing the client. Signed-in workflows require a compatible Supabase database and API, and maps may require a Mapbox public token. The portfolio also includes standalone examples that run with fictional data.

This snapshot excludes deployment configuration, production data, server-side services, and native app projects. See LICENSE for source terms.
